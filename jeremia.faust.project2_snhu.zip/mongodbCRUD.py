from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        # to improve reusibility for other project, it accepts database and collection as arguments
        self.client = MongoClient('mongodb://%s:%s@localhost:37136/?authMechanism=DEFAULT&authSource=admin' % (username, password))
        self.database = self.client['AAC']      # connect to database  
       
# Create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)                                   # data should be dictionary
        else:
            print("Nothing to save, because data parameter is empty")
            return False
                       
# Read method to implement the R in CRUD.
    def read(self, conditions):
        if conditions is not None:                                               # verify if condition is not blank                              
            return self.database.animals.find(conditions,{"_id":False})          # condition should be dictionary, exclude id
        else:
            print('Nothing to read, because data parameter is empty')
            return False
        
# Update method to implement the U in CRUD.
    def update(self, conditions, newValue):
        if conditions is not None:
            return self.database.animals.update(conditions,{ "$set": newValue}) # conditions and newValue are dictionaries
        else:
            print('Nothing to update, because data parameter is empty')
            return False
            
# Delete method to implement the D in CRUD.
    def delete(self, conditions):
        if conditions is not None:
            return self.database.animals.delete_one(conditions) # conditions is dictionary
        else:
            print('Nothing to delete, because data parameter is empty')
            return False         
            
            